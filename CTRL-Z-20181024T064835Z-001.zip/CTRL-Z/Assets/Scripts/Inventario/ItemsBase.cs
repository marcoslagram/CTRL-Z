﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemsBase : MonoBehaviour {

    public List<Items> myItems = new List<Items>();


    private void Start()
    {
       
    }
}
